
import { List, ListItem, Typography } from '@mui/material';

export default function URLList({ urls }) {
  return (
    <List sx={{ mt: 4 }}>
      {urls.map((url, i) => (
        <ListItem key={i} divider>
          <Typography variant="body1" sx={{ wordBreak: 'break-all' }}>
            🔗 <a href={url.short} target="_blank" rel="noreferrer">{url.short}</a><br />
            Created At: {new Date(url.createdAt).toLocaleString()}<br />
            {url.expiry && `Expires At: ${new Date(url.expiry).toLocaleString()}`}
          </Typography>
        </ListItem>
      ))}
    </List>
  );
}
