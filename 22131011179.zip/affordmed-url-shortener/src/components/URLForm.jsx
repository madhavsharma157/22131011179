
import { TextField, Button, Box, Grid } from '@mui/material';
import { useState } from 'react';
import axios from 'axios';

export default function URLForm({ onShorten }) {
  const [url, setUrl] = useState('');
  const [expiry, setExpiry] = useState('');
  const [shortcode, setShortcode] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post('http://localhost:3001/shorten', {
        url,
        expiry,
        shortcode
      });
      onShorten(res.data);
      setUrl('');
      setExpiry('');
      setShortcode('');
    } catch {
      alert('Error creating short URL');
    }
  };

  return (
    <Box component="form" onSubmit={handleSubmit} sx={{ mt: 3 }}>
      <Grid container spacing={2}>
        <Grid item xs={12}>
          <TextField fullWidth required label="Original URL" value={url} onChange={(e) => setUrl(e.target.value)} />
        </Grid>
        <Grid item xs={6}>
          <TextField fullWidth label="Expiry (in minutes)" type="number" value={expiry} onChange={(e) => setExpiry(e.target.value)} />
        </Grid>
        <Grid item xs={6}>
          <TextField fullWidth label="Custom Shortcode (optional)" value={shortcode} onChange={(e) => setShortcode(e.target.value)} />
        </Grid>
        <Grid item xs={12}>
          <Button type="submit" variant="contained" fullWidth>Generate Short URL</Button>
        </Grid>
      </Grid>
    </Box>
  );
}
