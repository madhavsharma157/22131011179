
import { useEffect, useState } from 'react';
import axios from 'axios';
import { Typography, List, ListItem } from '@mui/material';

export default function StatsPage() {
  const [stats, setStats] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:3001/stats').then(res => setStats(res.data));
  }, []);

  return (
    <div>
      <Typography variant="h5" gutterBottom>URL Click Statistics</Typography>
      <List>
        {stats.map((item, i) => (
          <ListItem key={i} divider>
            🔗 <a href={item.short} target="_blank" rel="noreferrer">{item.short}</a><br />
            Total Clicks: {item.clicks}<br />
            Last Click: {item.clickDetails?.slice(-1)[0]?.timestamp || 'Never'}
          </ListItem>
        ))}
      </List>
    </div>
  );
}
