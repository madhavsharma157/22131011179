
import React, { useState } from 'react';
import { Container, Typography, Button } from '@mui/material';
import URLForm from './components/URLForm';
import URLList from './components/URLList';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import StatsPage from './components/StatsPage';

export default function App() {
  const [urls, setUrls] = useState([]);

  const handleShorten = (data) => {
    setUrls((prev) => [...prev, data]);
  };

  return (
    <Router>
      <Container maxWidth="md">
        <Typography variant="h3" mt={4} align="center">AffordMed URL Shortener</Typography>
        <nav style={{ textAlign: 'center', margin: '20px' }}>
          <Button component={Link} to="/" variant="contained" sx={{ marginRight: 2 }}>Home</Button>
          <Button component={Link} to="/stats" variant="outlined">Statistics</Button>
        </nav>
        <Routes>
          <Route path="/" element={
            <>
              <URLForm onShorten={handleShorten} />
              <URLList urls={urls} />
            </>
          } />
          <Route path="/stats" element={<StatsPage />} />
        </Routes>
      </Container>
    </Router>
  );
}
