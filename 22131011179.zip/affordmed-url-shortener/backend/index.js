
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const { nanoid } = require('nanoid');

const app = express();
const PORT = 3001;

app.use(cors());
app.use(bodyParser.json());

const urlDatabase = {};
const clickStats = {};

// Shorten URL
app.post('/shorten', (req, res) => {
    const { url, expiry = 30, shortcode } = req.body;
    const code = shortcode || nanoid(6);
    const shortUrl = `http://localhost:3000/${code}`;
    const createdAt = new Date();

    urlDatabase[code] = {
        original: url,
        short: shortUrl,
        code,
        createdAt,
        expiry,
        clicks: 0
    };

    clickStats[code] = [];

    res.json(urlDatabase[code]);
});

// Redirect + log click
app.get('/:code', (req, res) => {
    const { code } = req.params;
    const data = urlDatabase[code];
    if (!data) {
        return res.status(404).send('Short URL not found');
    }

    data.clicks += 1;
    clickStats[code].push({
        timestamp: new Date(),
        source: req.get('Referrer') || 'Direct',
        geo: req.ip
    });

    res.redirect(data.original);
});

// Get stats
app.get('/stats', (req, res) => {
    const stats = Object.keys(urlDatabase).map(code => ({
        ...urlDatabase[code],
        clickDetails: clickStats[code]
    }));
    res.json(stats);
});

app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
